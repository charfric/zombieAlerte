#include <string.h>

#include "stringProcess.h"

char* extractSubstring(const char* inputString, int firstCharPos, int lastCharPos) {
    if (inputString == NULL || firstCharPos < 0 || lastCharPos < firstCharPos) {
        return NULL;
    }

    int length = lastCharPos - firstCharPos + 1;
    char* outputString = (char*)malloc((length + 1) * sizeof(char));

    if (outputString == NULL) {
        return NULL;
    }

    strncpy(outputString, inputString + firstCharPos, length);
    outputString[length] = '\0';

    return outputString;
}
