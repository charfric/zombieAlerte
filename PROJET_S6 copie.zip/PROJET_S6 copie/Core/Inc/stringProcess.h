/*
 * stringProcess.h
 *
 *  Created on: 5 juin 2023
 *      Author: hugodevaux
 */

#ifndef INC_STRINGPROCESS_H_
#define INC_STRINGPROCESS_H_



#endif /* INC_STRINGPROCESS_H_ */


char* extractSubstring(const char* inputString, int firstCharPos, int lastCharPos);
